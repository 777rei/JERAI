/**
 * JERAI Fitness — Workout Plans
 * 
 * Each plan contains:
 * - id: Unique identifier
 * - name: Display name
 * - desc: Short description
 * - diff: Difficulty level
 * - dur: Estimated duration in minutes
 * - color, gr, icon, ib, ic: Visual styling
 * - ex: Array of exercise entries
 *   - id: Exercise ID (references EX object)
 *   - r: Reps per set (or seconds for time-based)
 *   - s: Number of sets
 *   - rst: Rest time between sets (seconds)
 *   - t: Time-based flag (plank, wall sit)
 */

var WP = [
  {
    id: 'full-body', name: 'Full Body Blitz',
    desc: 'Hit every major muscle group', diff: 'Intermediate', dur: 22,
    color: '#00e676', gr: 'linear-gradient(135deg,#0a2018,#0d1a14)',
    icon: 'fa-fire', ib: 'rgba(0,230,118,.12)', ic: '#00e676',
    ex: [
      { id: 'pushups', r: 15, s: 3, rst: 30 },
      { id: 'squats', r: 20, s: 3, rst: 30 },
      { id: 'lunges', r: 12, s: 3, rst: 20 },
      { id: 'plank', r: 30, s: 2, rst: 20, t: true },
      { id: 'mountain-climbers', r: 20, s: 3, rst: 30 }
    ]
  },
  {
    id: 'upper', name: 'Upper Body Power',
    desc: 'Build chest, shoulders, arms', diff: 'Intermediate', dur: 18,
    color: '#ff6d3a', gr: 'linear-gradient(135deg,#201008,#1a0d05)',
    icon: 'fa-hand-fist', ib: 'rgba(255,109,58,.12)', ic: '#ff6d3a',
    ex: [
      { id: 'pushups', r: 12, s: 4, rst: 30 },
      { id: 'wide-pushups', r: 10, s: 3, rst: 30 },
      { id: 'diamond-pushups', r: 8, s: 3, rst: 30 },
      { id: 'tricep-dips', r: 15, s: 3, rst: 25 },
      { id: 'plank', r: 30, s: 2, rst: 20, t: true }
    ]
  },
  {
    id: 'lower', name: 'Lower Body Strength',
    desc: 'Sculpt legs and glutes', diff: 'Intermediate', dur: 16,
    color: '#00bcd4', gr: 'linear-gradient(135deg,#081a1a,#051414)',
    icon: 'fa-person-walking', ib: 'rgba(0,188,212,.12)', ic: '#00bcd4',
    ex: [
      { id: 'squats', r: 20, s: 3, rst: 30 },
      { id: 'lunges', r: 12, s: 3, rst: 25 },
      { id: 'jump-squats', r: 10, s: 3, rst: 35 },
      { id: 'calf-raises', r: 20, s: 3, rst: 20 },
      { id: 'glute-bridges', r: 15, s: 3, rst: 20 }
    ]
  },
  {
    id: 'core', name: 'Core Crusher',
    desc: 'Rock-solid midsection in 10 min', diff: 'Beginner', dur: 10,
    color: '#ffc107', gr: 'linear-gradient(135deg,#1a1808,#14120a)',
    icon: 'fa-shield-halved', ib: 'rgba(255,193,7,.12)', ic: '#ffc107',
    ex: [
      { id: 'crunches', r: 20, s: 3, rst: 20 },
      { id: 'situps', r: 15, s: 3, rst: 25 },
      { id: 'bicycle-crunches', r: 20, s: 3, rst: 20 },
      { id: 'plank', r: 30, s: 3, rst: 20, t: true }
    ]
  },
  {
    id: 'hiit', name: 'HIIT Cardio Blaster',
    desc: 'Maximum calorie burn', diff: 'Advanced', dur: 15,
    color: '#ff5252', gr: 'linear-gradient(135deg,#1a0808,#140505)',
    icon: 'fa-heart-pulse', ib: 'rgba(255,82,82,.12)', ic: '#ff5252',
    ex: [
      { id: 'burpees', r: 10, s: 3, rst: 40 },
      { id: 'jumping-jacks', r: 30, s: 3, rst: 20 },
      { id: 'mountain-climbers', r: 24, s: 3, rst: 30 },
      { id: 'high-knees', r: 30, s: 3, rst: 25 },
      { id: 'jump-squats', r: 12, s: 3, rst: 35 }
    ]
  },
  {
    id: 'morning', name: 'Morning Wake-Up',
    desc: 'Start your day energized', diff: 'Beginner', dur: 8,
    color: '#00e676', gr: 'linear-gradient(135deg,#0a1810,#0d1412)',
    icon: 'fa-sun', ib: 'rgba(0,230,118,.12)', ic: '#00e676',
    ex: [
      { id: 'jumping-jacks', r: 20, s: 2, rst: 15 },
      { id: 'squats', r: 12, s: 2, rst: 20 },
      { id: 'pushups', r: 8, s: 2, rst: 20 },
      { id: 'lunges', r: 8, s: 2, rst: 15 },
      { id: 'plank', r: 20, s: 2, rst: 15, t: true }
    ]
  },
  {
    id: 'arms', name: 'Arm Shredder',
    desc: 'Targeted arm intensity', diff: 'Intermediate', dur: 14,
    color: '#ff6d3a', gr: 'linear-gradient(135deg,#201008,#1a0d05)',
    icon: 'fa-hand-back-fist', ib: 'rgba(255,109,58,.12)', ic: '#ff6d3a',
    ex: [
      { id: 'pushups', r: 12, s: 3, rst: 25 },
      { id: 'diamond-pushups', r: 10, s: 3, rst: 25 },
      { id: 'wide-pushups', r: 10, s: 3, rst: 25 },
      { id: 'tricep-dips', r: 15, s: 3, rst: 20 },
      { id: 'pike-pushups', r: 8, s: 3, rst: 25 }
    ]
  },
  {
    id: 'legday', name: 'Leg Day Extreme',
    desc: 'No walking tomorrow', diff: 'Advanced', dur: 20,
    color: '#00bcd4', gr: 'linear-gradient(135deg,#081a1a,#051414)',
    icon: 'fa-person-walking', ib: 'rgba(0,188,212,.12)', ic: '#00bcd4',
    ex: [
      { id: 'squats', r: 25, s: 4, rst: 30 },
      { id: 'jump-squats', r: 12, s: 3, rst: 35 },
      { id: 'lunges', r: 15, s: 3, rst: 25 },
      { id: 'reverse-lunges', r: 12, s: 3, rst: 25 },
      { id: 'wall-sit', r: 45, s: 2, rst: 20, t: true },
      { id: 'calf-raises', r: 25, s: 3, rst: 20 }
    ]
  }
];