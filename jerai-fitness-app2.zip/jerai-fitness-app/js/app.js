/**
 * JERAI Fitness — Main Application Logic
 * 
 * Handles: navigation, camera, AI counting, manual counting,
 * rest timer, workout engine, history, profile, audio, storage
 */

/* ==============================================
   UTILITY FUNCTIONS
   ============================================== */

/**
 * Calculate angle between three landmark points (in degrees)
 * @param {Object} a - First point {x, y}
 * @param {Object} b - Vertex point {x, y}
 * @param {Object} c - Third point {x, y}
 * @returns {number} Angle in degrees (0-180)
 */
function ang(a, b, c) {
  var ba = { x: a.x - b.x, y: a.y - b.y };
  var bc = { x: c.x - b.x, y: c.y - b.y };
  var d = ba.x * bc.x + ba.y * bc.y;
  var m1 = Math.sqrt(Math.max(1e-8, ba.x * ba.x + ba.y * ba.y));
  var m2 = Math.sqrt(Math.max(1e-8, bc.x * bc.x + bc.y * bc.y));
  return Math.acos(Math.max(-1, Math.min(1, d / (m1 * m2)))) * 180 / Math.PI;
}

/**
 * Calculate Euclidean distance between two points
 */
function dst(a, b) {
  return Math.sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
}

/**
 * Get time-based greeting
 */
function greet() {
  var h = new Date().getHours();
  return h < 12 ? 'Good Morning' : h < 17 ? 'Good Afternoon' : 'Good Evening';
}

/**
 * Format seconds to M:SS
 */
function fmtDur(s) {
  return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
}

/**
 * Format ISO date to readable string
 */
function fmtDate(iso) {
  return new Date(iso).toLocaleDateString('en-US', {
    weekday: 'short', month: 'short', day: 'numeric'
  });
}

/**
 * Generate unique ID
 */
function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

/**
 * Format time target (for plank/wall sit)
 */
function fmtTgt(r) {
  return r >= 60 ? Math.floor(r / 60) + 'm ' + (r % 60 ? r % 60 + 's' : '') + ' hold' : r + 's hold';
}

/**
 * Format elapsed seconds
 */
function fmtTm(s) {
  return s >= 60 ? Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0') : s + 's';
}


/* ==============================================
   CAMERA STATUS DETECTION
   ============================================== */

/** Current camera availability status */
var camStatus = 'unknown';

/**
 * Detect why camera might not be available
 * Sets camStatus to: 'available', 'no_api', 'no_https', 'denied', 'no_device'
 */
function detectCamStatus() {
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    camStatus = 'no_api';
    return;
  }
  if (!window.isSecureContext) {
    camStatus = 'no_https';
    return;
  }
  camStatus = 'available';
}

/**
 * Get human-readable message for current camera status
 */
function getCamStatusMsg() {
  switch (camStatus) {
    case 'no_https':
      return 'Camera needs HTTPS. Open this page via a local server or host it online. Using manual mode.';
    case 'no_api':
      return 'Your browser does not support camera access. Using manual mode.';
    case 'denied':
      return 'Camera permission was denied. Go to browser settings to allow camera, then reload.';
    case 'no_device':
      return 'No camera found on this device. Using manual mode.';
    default:
      return 'Camera unavailable. Tap the button below to count reps manually.';
  }
}


/* ==============================================
   AUDIO SYSTEM (Web Audio API)
   ============================================== */

var Snd = {
  ctx: null,

  /** Initialize audio context (must be called after user interaction) */
  init: function () {
    if (!this.ctx) this.ctx = new (window.AudioContext || window.webkitAudioContext)();
    if (this.ctx.state === 'suspended') this.ctx.resume();
  },

  /** Play a tone */
  tone: function (freq, dur, type, vol) {
    try {
      this.init();
      var o = this.ctx.createOscillator();
      var g = this.ctx.createGain();
      o.connect(g);
      g.connect(this.ctx.destination);
      o.frequency.value = freq;
      o.type = type || 'sine';
      g.gain.setValueAtTime(vol || 0.12, this.ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + dur);
      o.start();
      o.stop(this.ctx.currentTime + dur);
    } catch (e) { /* silent fail */ }
  },

  rep: function () { this.tone(880, 0.05, 'sine', 0.1) },
  half: function () { this.tone(660, 0.08, 'sine', 0.08) },
  cd: function () { this.tone(440, 0.07, 'square', 0.06) },
  go: function () { this.tone(880, 0.12, 'square', 0.1) },

  set: function () {
    var s = this;
    this.tone(523, 0.1);
    setTimeout(function () { s.tone(659, 0.1) }, 70);
    setTimeout(function () { s.tone(784, 0.2, 'sine', 0.14) }, 140);
  },

  done: function () {
    var s = this;
    [523, 659, 784, 1047].forEach(function (f, i) {
      setTimeout(function () { s.tone(f, 0.25, 'sine', 0.13) }, i * 110);
    });
  }
};


/* ==============================================
   TOAST NOTIFICATION SYSTEM
   ============================================== */

/**
 * Show a toast notification
 * @param {string} msg - Message text
 * @param {string} type - 'suc'|'err'|'inf'|'wrn'
 * @param {number} dur - Duration in ms
 */
function toast(msg, type, dur) {
  var c = document.getElementById('tc');
  var t = document.createElement('div');
  t.className = 'toast ' + (type || 'inf');
  var icons = { suc: 'fa-circle-check', err: 'fa-circle-xmark', inf: 'fa-circle-info', wrn: 'fa-triangle-exclamation' };
  t.innerHTML = '<i class="fas ' + (icons[type] || icons.inf) + '"></i>' + msg;
  c.appendChild(t);
  setTimeout(function () {
    t.style.opacity = '0';
    t.style.transform = 'translateY(-8px)';
    t.style.transition = 'all .25s';
    setTimeout(function () { t.remove() }, 250);
  }, dur || 3000);
}


/* ==============================================
   CONFETTI EFFECT
   ============================================== */

function confetti() {
  var cols = ['#00e676', '#ff6d3a', '#ffc107', '#00bcd4', '#ff4081', '#7c4dff'];
  var c = document.getElementById('confC');
  for (var i = 0; i < 50; i++) {
    var p = document.createElement('div');
    p.className = 'cfp';
    p.style.left = (8 + Math.random() * 84) + '%';
    p.style.backgroundColor = cols[Math.floor(Math.random() * cols.length)];
    p.style.animationDelay = (Math.random() * 0.5) + 's';
    p.style.animationDuration = (1 + Math.random() * 1.4) + 's';
    p.style.width = (4 + Math.random() * 7) + 'px';
    p.style.height = (4 + Math.random() * 7) + 'px';
    p.style.borderRadius = Math.random() > 0.5 ? '50%' : '2px';
    c.appendChild(p);
    (function (el) {
      setTimeout(function () { el.remove() }, 3000);
    })(p);
  }
}


/* ==============================================
   LOADING OVERLAY
   ============================================== */

function showLoad(t) {
  document.getElementById('ltxt').textContent = t || 'Loading...';
  document.getElementById('lo').classList.add('vis');
}

function hideLoad() {
  document.getElementById('lo').classList.remove('vis');
}


/* ==============================================
   LOCAL STORAGE (DATA PERSISTENCE)
   ============================================== */

var DB = {
  _d: null,

  /** Default data structure */
  def: function () {
    return {
      w: [],       // Workout history array
      set: { sound: true }, // Settings
      st: { tw: 0, tr: 0, td: 0, cs: 0, ls: 0, jd: new Date().toISOString() }, // Stats
      wd: {}       // Weekly data: { '2024-01-15': { r: 45, d: 600 } }
    };
  },

  /** Load from localStorage */
  load: function () {
    try {
      var r = localStorage.getItem('jerai');
      this._d = r ? JSON.parse(r) : this.def();
    } catch (e) { this._d = this.def(); }
    if (!this._d.wd) this._d.wd = {};
    if (!this._d.st.jd) this._d.st.jd = new Date().toISOString();
  },

  /** Save to localStorage */
  save: function () {
    try { localStorage.setItem('jerai', JSON.stringify(this._d)); } catch (e) { /* storage full */ }
  },

  /** Get a top-level key */
  get: function (k) { return this._d[k]; },

  /** Set a top-level key */
  set: function (k, v) { this._d[k] = v; this.save(); },

  /** Add completed workout to history */
  addW: function (w) {
    this._d.w.unshift(w);
    this._d.st.tw++;
    this._d.st.tr += w.tr;
    this._d.st.td += w.dur;
    this._upS();
    this._upW(w);
    this.save();
  },

  /** Recalculate streak */
  _upS: function () {
    var td = new Date().toDateString();
    var yd = new Date(Date.now() - 864e5).toDateString();
    var s = 0;
    var w = this._d.w;
    if (w.length) {
      var ld = new Date(w[0].date).toDateString();
      if (ld === td || ld === yd) {
        s = 1;
        for (var i = 1; i < w.length; i++) {
          var d1 = new Date(w[i - 1].date).toDateString();
          var d2 = new Date(w[i].date).toDateString();
          if (Math.round((new Date(d1) - new Date(d2)) / 864e5) === 1) s++;
          else break;
        }
      }
    }
    this._d.st.cs = s;
    this._d.st.ls = Math.max(this._d.st.ls, s);
  },

  /** Update weekly chart data */
  _upW: function (w) {
    var k = new Date(w.date).toISOString().split('T')[0];
    if (!this._d.wd[k]) this._d.wd[k] = { r: 0, d: 0 };
    this._d.wd[k].r += w.tr;
    this._d.wd[k].d += w.dur;
  }
};


/* ==============================================
   APP STATE
   ============================================== */

var curScr = 's-home';  // Current active screen
var ws = null;           // Active workout state
var poseInst = null;     // MediaPipe Pose instance
var camStream = null;    // Camera MediaStream
var camOn = false;       // Is camera actively running
var camPause = false;    // Is camera paused
var rafId = null;        // requestAnimationFrame ID
var rcState = { phase: 'up', reps: 0, cd: 0 }; // Rep counting state
var restInt = null;      // Rest timer interval
var plankInt = null;     // Plank/wall-sit timer interval
var ffTimer = 0;         // Form feedback timeout


/* ==============================================
   NAVIGATION
   ============================================== */

/**
 * Navigate to a screen tab
 * @param {string} id - Screen element ID (e.g. 's-home')
 */
function nav(id) {
  // Block navigation during active workout
  if (ws) return;

  document.querySelectorAll('.screen').forEach(function (s) {
    s.classList.remove('active');
  });
  var el = document.getElementById(id);
  if (el) el.classList.add('active');
  curScr = id;

  // Update nav highlight
  document.querySelectorAll('.ni,.nstart').forEach(function (n) {
    n.classList.remove('active');
  });
  var b = document.querySelector('[data-s="' + id + '"]');
  if (b) b.classList.add('active');

  // Refresh screen content
  if (id === 's-home') renderHome();
  if (id === 's-exer') renderEx();
  if (id === 's-wsel') renderWSel();
  if (id === 's-hist') renderHist();
  if (id === 's-prof') renderProf();
}

/** Show a screen without nav highlight (for sub-screens) */
function showScr(id) {
  document.querySelectorAll('.screen').forEach(function (s) {
    s.classList.remove('active');
  });
  document.getElementById(id).classList.add('active');
  curScr = id;
}


/* ==============================================
   HOME SCREEN
   ============================================== */

function renderHome() {
  document.getElementById('grt').textContent = greet();
  var st = DB.get('st');
  document.getElementById('hStrk').textContent = st.cs;
  document.getElementById('hWkt').textContent = st.tw;

  // Weekly chart
  var ch = document.getElementById('wChart');
  var days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  var td = new Date();
  var dow = (td.getDay() + 6) % 7;
  var wd = DB.get('wd') || {};
  var mx = 1;
  var wk = [];

  for (var i = 0; i < 7; i++) {
    var d = new Date(td);
    d.setDate(d.getDate() - dow + i);
    var k = d.toISOString().split('T')[0];
    var v = wd[k] || { r: 0 };
    wk.push({ day: days[i], r: v.r, tod: i === dow });
    mx = Math.max(mx, v.r);
  }

  ch.innerHTML = wk.map(function (w) {
    var h = w.r > 0 ? Math.max(6, (w.r / mx) * 76) : 3;
    return '<div class="cw"><div class="cb' + (w.tod ? ' tod' : '') + (w.r === 0 ? ' emp' : '') + '" style="height:' + h + 'px"></div><div class="cd">' + w.day + '</div></div>';
  }).join('');

  // Plan cards (first 3)
  var pc = document.getElementById('hPlans');
  pc.innerHTML = '';
  WP.slice(0, 3).forEach(function (p) { pc.innerHTML += mkPC(p); });
}

/**
 * Generate a plan card HTML string
 */
function mkPC(p) {
  var n = p.ex.length;
  var dc = { Beginner: 'bg-g', Intermediate: 'bg-o', Advanced: 'bg-r' }[p.diff] || 'bg-g';
  return '<button class="card pc" style="background:' + p.gr + ';border-color:' + p.color + '18" onclick="openWP(\'' + p.id + '\')">' +
    '<div class="pi" style="background:' + p.ib + ';color:' + p.ic + '"><i class="fas ' + p.icon + '"></i></div>' +
    '<div class="pn">' + p.name + '</div>' +
    '<div class="pd">' + p.desc + '</div>' +
    '<div class="pm"><div class="mi"><i class="fas fa-clock"></i>' + p.dur + ' min</div><div class="mi"><i class="fas fa-layer-group"></i>' + n + ' exercises</div><span class="badge ' + dc + '">' + p.diff + '</span></div>' +
    '<div class="pa"><i class="fas fa-chevron-right"></i></div></button>';
}


/* ==============================================
   EXERCISES SCREEN
   ============================================== */

var CATS = [
  { id: 'all', l: 'All' },
  { id: 'upper', l: 'Upper Body' },
  { id: 'lower', l: 'Lower Body' },
  { id: 'core', l: 'Core' },
  { id: 'cardio', l: 'Cardio' }
];
var actCat = 'all';

function renderEx() {
  document.getElementById('catPills').innerHTML = CATS.map(function (c) {
    return '<button class="pill' + (c.id === actCat ? ' on' : '') + '" onclick="filtEx(\'' + c.id + '\')">' + c.l + '</button>';
  }).join('');

  var g = document.getElementById('exGrid');
  var fl = actCat === 'all' ? Object.values(EX) : Object.values(EX).filter(function (e) { return e.cat === actCat });
  g.innerHTML = fl.map(function (e) {
    return '<button class="card ec" onclick="openED(\'' + e.id + '\')">' +
      '<div class="ea" style="background:' + e.gr + '"><i class="fas ' + e.icon + '" style="color:' + e.ic + '"></i></div>' +
      (e.ai ? '<div class="aib badge bg-ai"><i class="fas fa-microchip"></i>AI</div>' : '') +
      '<div class="en">' + e.name + '</div><div class="em">' + e.muscle + '</div></button>';
  }).join('');
}

function filtEx(c) {
  actCat = c;
  renderEx();
}


/* ==============================================
   EXERCISE DETAIL SCREEN
   ============================================== */

function openED(id) {
  var e = EX[id];
  if (!e) return;
  var dc = { Beginner: 'bg-g', Intermediate: 'bg-o', Advanced: 'bg-r' }[e.diff] || 'bg-g';

  document.getElementById('edetC').innerHTML =
    '<div class="dh" style="background:' + e.gr + '">' +
    '<button class="btn-i" style="position:absolute;left:14px;top:max(14px,env(safe-area-inset-top))" onclick="nav(\'s-exer\')"><i class="fas fa-arrow-left"></i></button>' +
    '<div class="di" style="background:' + e.ib + ';color:' + e.ic + '"><i class="fas ' + e.icon + '"></i></div>' +
    '<div class="dn">' + e.name + '</div><div class="dm">' + e.muscle + '</div>' +
    '<div style="margin-top:8px;display:flex;gap:6px;justify-content:center;flex-wrap:wrap">' +
    '<span class="badge ' + dc + '">' + e.diff + '</span>' +
    (e.ai ? '<span class="badge bg-ai"><i class="fas fa-microchip"></i>AI Counting</span>' : '') +
    (e.tb ? '<span class="badge bg-c">Time-Based</span>' : '') +
    '</div></div>' +
    '<div class="ds"><div class="dt">How to Perform</div><ul class="dil">' +
    e.ins.map(function (s, i) { return '<li><div class="sn">' + (i + 1) + '</div><div>' + s + '</div></li>'; }).join('') +
    '</ul></div>' +
    '<div class="ds"><div class="dt">Tips</div><ul class="dtl">' +
    e.tips.map(function (t) { return '<li><i class="fas fa-lightbulb"></i><span>' + t + '</span></li>'; }).join('') +
    '</ul></div>' +
    '<div style="margin:28px 20px 20px"><button class="btn btn-p" style="width:100%" onclick="startSingle(\'' + e.id + '\')"><i class="fas fa-play"></i> Start Exercise</button></div>';

  showScr('s-edet');
}


/* ==============================================
   WORKOUT SELECT SCREEN
   ============================================== */

function renderWSel() {
  document.getElementById('allPlans').innerHTML = WP.map(function (p) { return mkPC(p); }).join('');
}


/* ==============================================
   WORKOUT PREVIEW SCREEN
   ============================================== */

function openWP(pid) {
  var p = WP.find(function (x) { return x.id === pid; });
  if (!p) return;
  var ts = p.ex.reduce(function (s, e) { return s + e.s; }, 0);
  var dc = { Beginner: 'bg-g', Intermediate: 'bg-o', Advanced: 'bg-r' }[p.diff] || 'bg-g';

  document.getElementById('wpC').innerHTML =
    '<div class="pty" style="background:' + p.gr + ';padding-top:max(56px,calc(env(safe-area-inset-top)+36px))">' +
    '<button class="btn-i pb" onclick="nav(\'s-wsel\')"><i class="fas fa-arrow-left"></i></button>' +
    '<div class="pyn">' + p.name + '</div><div class="pyd">' + p.desc + '</div>' +
    '<div class="pym"><div><div class="v">' + p.dur + '</div><div class="l">Minutes</div></div>' +
    '<div><div class="v">' + p.ex.length + '</div><div class="l">Exercises</div></div>' +
    '<div><div class="v">' + ts + '</div><div class="l">Total Sets</div></div>' +
    '<div><span class="badge ' + dc + '">' + p.diff + '</span></div></div></div>' +
    '<div class="pxl"><div class="dt" style="margin-bottom:6px">Exercises</div>' +
    p.ex.map(function (e, i) {
      var ed = EX[e.id];
      var rt = e.t ? e.r + 's hold' : e.r + ' reps';
      return '<div class="pxr"><div class="pnum">' + (i + 1) + '</div>' +
        '<div class="pif"><div class="nm">' + (ed ? ed.name : e.id) + '</div>' +
        '<div class="dt">' + rt + ' x ' + e.s + ' sets' + (e.rst ? ' · ' + e.rst + 's rest' : '') + '</div></div>' +
        '<div class="prp">' + (ed && ed.ai ? '<i class="fas fa-microchip" style="color:var(--accent);font-size:11px"></i>' : '') + '</div></div>';
    }).join('') + '</div>' +
    '<div class="pxst"><button class="btn btn-p" style="width:100%;padding:15px;font-size:15px" onclick="startWK(\'' + p.id + '\')"><i class="fas fa-play"></i> Start Workout</button></div>';

  showScr('s-wprev');
}


/* ==============================================
   WORKOUT ENGINE
   ============================================== */

/** Start a predefined workout plan */
function startWK(pid) {
  var p = WP.find(function (x) { return x.id === pid; });
  if (!p) return;
  ws = {
    pid: p.id, pn: p.name, st: Date.now(), ei: 0, si: 0,
    ex: p.ex.map(function (e) {
      return { id: e.id, r: e.r, s: e.s, rst: e.rst, t: e.t || false, ed: EX[e.id], sr: [] };
    }),
    done: false
  };
  startCurEx();
}

/** Start a single exercise (from exercise detail) */
function startSingle(eid) {
  var e = EX[eid];
  if (!e) return;
  ws = {
    pid: 'single', pn: e.name, st: Date.now(), ei: 0, si: 0,
    ex: [{ id: eid, r: e.tb ? 30 : 15, s: 3, rst: 20, t: e.tb || false, ed: e, sr: [] }],
    done: false
  };
  startCurEx();
}

/** Start a randomly generated workout */
function startRandom(type) {
  var pool = Object.values(EX);
  if (type === 'cardio') pool = pool.filter(function (e) { return e.cat === 'cardio'; });
  pool.sort(function () { return Math.random() - 0.5; });
  var pk = pool.slice(0, Math.min(5, pool.length));
  ws = {
    pid: 'custom', pn: type === 'cardio' ? 'Quick Cardio' : 'Random Workout',
    st: Date.now(), ei: 0, si: 0,
    ex: pk.map(function (e) {
      return { id: e.id, r: e.tb ? 20 : (8 + Math.floor(Math.random() * 13)), s: 3, rst: 20, t: e.tb || false, ed: e, sr: [] };
    }),
    done: false
  };
  startCurEx();
}

/** Start the current exercise in the workout */
function startCurEx() {
  if (!ws) return;
  var e = ws.ex[ws.ei];
  if (!e) { finishWK(); return; }

  // Reset rep counting state
  rcState = { phase: (e.ed.cnt && e.ed.cnt.sp) || 'up', reps: 0, cd: 0, _ht: false, _htSide: 0 };

  // Choose mode: camera AI, time-based, or manual tap
  if (e.ed.ai && e.ed.cnt && !e.t) {
    startCamEx(e);
  } else if (e.t) {
    startTimeEx(e);
  } else {
    startManEx(e, false);
  }
}


/* ==============================================
   CAMERA EXERCISE (AI COUNTING)
   ============================================== */

/**
 * Start an exercise with AI camera counting
 * Falls back to manual mode if camera unavailable
 */
function startCamEx(e) {
  var ed = e.ed;

  // Pre-check camera availability before showing camera UI
  detectCamStatus();

  if (camStatus !== 'available') {
    document.getElementById('camWarnText').textContent = getCamStatusMsg();
    startManEx(e, true);
    if (camStatus === 'no_https') {
      toast('Open via HTTPS or localhost for AI camera', 'wrn', 4000);
    }
    return;
  }

  // Show camera UI
  var scr = document.getElementById('camScr');
  scr.classList.add('vis');
  document.getElementById('camEN').textContent = ed.name;
  updCamSI();
  document.getElementById('camRT').textContent = 'Target: ' + e.r;
  document.getElementById('camRN').textContent = '0';
  document.getElementById('camPF').style.width = '0%';
  document.getElementById('camDot').className = 'dot off';
  document.getElementById('camDT').textContent = 'Requesting camera...';
  hideFF();
  camPause = false;
  document.getElementById('camPB').innerHTML = '<i class="fas fa-pause"></i>';
  document.getElementById('camPB').classList.remove('act');
  showLoad('Requesting camera access...');

  // Hard timeout — fallback to manual after 15 seconds
  var fallbackTO = setTimeout(function () {
    hideLoad();
    camStatus = 'no_device';
    document.getElementById('camWarnText').textContent = getCamStatusMsg();
    scr.classList.remove('vis');
    stopCam();
    startManEx(e, true);
    toast('Camera timed out — manual mode', 'wrn');
  }, 15000);

  // Step 1: Get camera stream
  navigator.mediaDevices.getUserMedia({
    video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } },
    audio: false
  })
  .then(function (stream) {
    if (!ws || ws.done) { stream.getTracks().forEach(function (t) { t.stop() }); return; }
    camStream = stream;

    var vid = document.getElementById('camVid');
    vid.srcObject = stream;
    vid.setAttribute('playsinline', '');
    vid.setAttribute('autoplay', '');
    vid.muted = true;
    document.getElementById('camDT').textContent = 'Camera on — loading AI...';
    document.getElementById('ltxt').textContent = 'Loading AI pose model (first time may take 10-20s)...';

    // Step 2: Wait for video to be ready
    return new Promise(function (resolve, reject) {
      if (vid.readyState >= 2) { resolve(); }
      else { vid.onloadeddata = function () { resolve(); }; vid.onerror = function () { reject(new Error('Video load error')); }; }
      setTimeout(function () { reject(new Error('Video ready timeout')); }, 8000);
    });
  })
  .then(function () {
    if (!ws || ws.done) return;
    var vid = document.getElementById('camVid');
    var cvs = document.getElementById('camCvs');
    cvs.width = vid.videoWidth || 640;
    cvs.height = vid.videoHeight || 480;

    // Step 3: Initialize MediaPipe Pose
    if (typeof Pose === 'undefined') { throw new Error('Pose model not loaded'); }

    if (!poseInst) {
      poseInst = new Pose({
        locateFile: function (f) { return 'https://cdn.jsdelivr.net/npm/@mediapipe/pose/' + f; }
      });
      poseInst.setOptions({
        modelComplexity: 1,
        smoothLandmarks: true,
        enableSegmentation: false,
        minDetectionConfidence: 0.5,
        minTrackingConfidence: 0.5
      });
      poseInst.onResults(onPoseResults);
    }

    // Step 4: Send test frame to trigger model download
    document.getElementById('ltxt').textContent = 'Warming up AI model...';
    return poseInst.send({ image: vid });
  })
  .then(function () {
    if (!ws || ws.done) return;
    clearTimeout(fallbackTO);
    camOn = true;
    hideLoad();
    document.getElementById('camDot').className = 'dot on';
    document.getElementById('camDT').textContent = 'Pose detected — counting active';
    Snd.init();
    detectLoop();
  })
  .catch(function (err) {
    clearTimeout(fallbackTO);
    hideLoad();
    console.warn('Camera setup:', err.name || err.message || err);

    // Classify the error for helpful messaging
    if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
      camStatus = 'denied';
    } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
      camStatus = 'no_device';
    } else if (err.message && err.message.indexOf('Pose') !== -1) {
      camStatus = 'no_api';
    } else {
      camStatus = 'no_device';
    }

    document.getElementById('camWarnText').textContent = getCamStatusMsg();
    stopCam();
    scr.classList.remove('vis');
    startManEx(e, true);
    toast(getCamStatusMsg(), 'wrn', 3500);
  });
}

/** Continuous detection loop using requestAnimationFrame */
function detectLoop() {
  if (!camOn || !ws || ws.done) return;
  if (!camPause) {
    var vid = document.getElementById('camVid');
    if (vid.readyState >= 2) {
      poseInst.send({ image: vid }).catch(function () { /* skip frame */ });
    }
  }
  rafId = requestAnimationFrame(detectLoop);
}

/**
 * Handle MediaPipe pose results
 * Draws skeleton, processes rep counting, checks form
 */
function onPoseResults(results) {
  if (!ws || !camOn) return;

  var cvs = document.getElementById('camCvs');
  var ctx = cvs.getContext('2d');
  var w = cvs.width, h = cvs.height;

  // Draw mirrored video frame
  ctx.clearRect(0, 0, w, h);
  ctx.save();
  ctx.scale(-1, 1);
  ctx.drawImage(results.image, -w, 0, w, h);
  ctx.restore();
  ctx.fillStyle = 'rgba(0,0,0,0.12)';
  ctx.fillRect(0, 0, w, h);

  if (results.poseLandmarks) {
    var lm = results.poseLandmarks;
    var e = ws.ex[ws.ei];
    if (!e) return;
    var ed = e.ed;
    var cfg = ed.cnt;

    document.getElementById('camDot').className = 'dot on';
    document.getElementById('camDT').textContent = 'Pose detected — counting active';

    // Collect active joints for highlighting
    var aj = {};
    function addJ(j) { aj[j] = true; }
    if (cfg.j) cfg.j.forEach(function (s) { s.forEach(addJ); });
    if (cfg.rj) cfg.rj.forEach(function (s) { s.forEach(addJ); });
    if (cfg.nj) cfg.nj.forEach(function (s) { s.forEach(addJ); });
    if (cfg.kj) cfg.kj.forEach(addJ);
    if (cfg.hj) cfg.hj.forEach(addJ);

    // Draw skeleton overlay
    drawSkel(ctx, lm, aj, w, h);

    // Process rep counting
    processCount(lm, cfg, e);

    // Form check
    if (ed.form && rcState.cd === 0) {
      var f = ed.form(lm);
      showFF(f.m, f.g);
    }
  } else {
    document.getElementById('camDot').className = 'dot off';
    document.getElementById('camDT').textContent = 'Step into frame';
  }

  if (rcState.cd > 0) rcState.cd--;
}

/**
 * Draw pose skeleton on canvas
 */
function drawSkel(ctx, lm, aj, w, h) {
  var conns = [
    [11, 12, 0], [11, 13, 2], [13, 15, 2], [12, 14, 1], [14, 16, 1],
    [11, 23, 2], [12, 24, 1], [23, 24, 0], [23, 25, 2], [25, 27, 2],
    [24, 26, 1], [26, 28, 1]
  ];
  var lc = '#00e676', rc2 = '#00bcd4', cc = 'rgba(255,255,255,0.4)', ac = '#ff6d3a';

  // Draw connections
  conns.forEach(function (c) {
    var i = c[0], j = c[1], t = c[2];
    var a = lm[i], b = lm[j];
    if (!a || !b || a.visibility < 0.5 || b.visibility < 0.5) return;
    var isA = aj[i] && aj[j];
    ctx.beginPath();
    ctx.moveTo(a.x * w, a.y * h);
    ctx.lineTo(b.x * w, b.y * h);
    ctx.strokeStyle = isA ? ac : (t === 0 ? cc : t === 1 ? rc2 : lc);
    ctx.lineWidth = isA ? 4 : 2;
    ctx.lineCap = 'round';
    ctx.stroke();
  });

  // Draw joint points
  [11, 12, 13, 14, 15, 16, 23, 24, 25, 26, 27, 28].forEach(function (i) {
    var p = lm[i];
    if (!p || p.visibility < 0.5) return;
    var isA = aj[i];
    ctx.beginPath();
    ctx.arc(p.x * w, p.y * h, isA ? 6 : 3, 0, Math.PI * 2);
    ctx.fillStyle = isA ? ac : 'rgba(255,255,255,0.6)';
    ctx.fill();
    if (isA) {
      ctx.beginPath();
      ctx.arc(p.x * w, p.y * h, 10, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(255,109,58,0.3)';
      ctx.lineWidth = 2;
      ctx.stroke();
    }
  });
}

/**
 * Process rep counting based on exercise config
 * Supports: angle, distance, height, and time methods
 */
function processCount(lm, cfg, ex) {
  var target = ex.r;
  var triggered = false;

  if (cfg.m === 'angle') {
    var angles = [];
    cfg.j.forEach(function (pair) {
      var a = pair[0], b = pair[1], c = pair[2];
      if (lm[a] && lm[b] && lm[c] && lm[a].visibility > 0.5 && lm[b].visibility > 0.5 && lm[c].visibility > 0.5) {
        angles.push(ang(lm[a], lm[b], lm[c]));
      }
    });
    if (!angles.length) return;
    var avg = cfg.mn ? Math.min.apply(null, angles) : Math.max.apply(null, angles);
    if (rcState.phase === 'up' && avg < cfg.dTh) { rcState.phase = 'down'; }
    else if (rcState.phase === 'down' && avg > cfg.uTh) { rcState.phase = 'up'; triggered = true; }

  } else if (cfg.m === 'dist') {
    var dists = [];
    for (var i = 0; i < cfg.rj.length; i++) {
      var rj1 = cfg.rj[i][0], rj2 = cfg.rj[i][1];
      var nj1 = cfg.nj[i][0], nj2 = cfg.nj[i][1];
      if (lm[rj1] && lm[rj2] && lm[nj1] && lm[nj2]) {
        var rd = dst(lm[rj1], lm[rj2]);
        var nd = dst(lm[nj1], lm[nj2]);
        if (nd > 0.01) dists.push(rd / nd);
      }
    }
    if (!dists.length) return;
    var avg = dists.reduce(function (a, b) { return a + b; }) / dists.length;
    if (rcState.phase === 'close' && avg > cfg.fTh) { rcState.phase = 'far'; }
    else if (rcState.phase === 'far' && avg < cfg.cTh) { rcState.phase = 'close'; triggered = true; }

  } else if (cfg.m === 'ht') {
    var hts = [];
    for (var i = 0; i < cfg.kj.length; i++) {
      var k = lm[cfg.kj[i]], h = lm[cfg.hj[i]];
      if (k && h && k.visibility > 0.5 && h.visibility > 0.5) {
        hts.push(Math.abs(k.y - h.y));
      }
    }
    if (!hts.length) return;
    var avg = hts.reduce(function (a, b) { return a + b; }) / hts.length;
    if (avg < cfg.hTh) {
      if (!rcState._ht) {
        rcState._ht = true;
        if (cfg.cps) rcState._htSide = (rcState._htSide || 0) + 1;
        if (!cfg.cps || rcState._htSide >= 2) { triggered = true; rcState._htSide = 0; }
      }
    } else { rcState._ht = false; }
  }

  // Handle successful rep count
  if (triggered && rcState.cd === 0) {
    rcState.reps++;
    rcState.cd = 12; // Cooldown frames to prevent double-counting

    var db = DB.get('set');
    if (db.sound) Snd.rep();

    // Visual feedback
    var el = document.getElementById('camRN');
    el.textContent = rcState.reps;
    el.classList.add('bmp');
    setTimeout(function () { el.classList.remove('bmp'); }, 100);

    // Progress bar
    document.getElementById('camPF').style.width = Math.min(100, (rcState.reps / target) * 100) + '%';

    // Halfway beep
    if (rcState.reps === Math.floor(target / 2) && db.sound) Snd.half();

    // Target reached
    if (rcState.reps >= target) { onSetDone(ex); }
  }
}

/** Show form feedback text on camera */
function showFF(msg, good) {
  var el = document.getElementById('camFF');
  el.textContent = msg;
  el.className = 'cff sh ' + (good ? 'gd' : 'bd');
  clearTimeout(ffTimer);
  ffTimer = setTimeout(function () { el.classList.remove('sh'); }, 2000);
}

function hideFF() { document.getElementById('camFF').classList.remove('sh'); }
function updCamSI() { if (!ws) return; var e = ws.ex[ws.ei]; document.getElementById('camSI').textContent = 'Set ' + (ws.si + 1) + ' of ' + e.s; }
function togglePause() {
  camPause = !camPause;
  var btn = document.getElementById('camPB');
  btn.innerHTML = camPause ? '<i class="fas fa-play"></i>' : '<i class="fas fa-pause"></i>';
  btn.classList.toggle('act', camPause);
  document.getElementById('camDT').textContent = camPause ? 'Paused' : 'Pose detected — counting active';
}

/** Stop camera and release resources */
function stopCam() {
  camOn = false;
  if (rafId) { cancelAnimationFrame(rafId); rafId = null; }
  if (camStream) { camStream.getTracks().forEach(function (t) { t.stop(); }); camStream = null; }
  document.getElementById('camVid').srcObject = null;
  poseInst = null;
}

function exitCam() { stopCam(); document.getElementById('camScr').classList.remove('vis'); endEarly(); }


/* ==============================================
   MANUAL COUNT EXERCISE (TAP TO COUNT)
   ============================================== */

/**
 * Start manual tap-counting mode
 * @param {Object} e - Exercise entry
 * @param {boolean} showWarn - Show camera warning banner
 */
function startManEx(e, showWarn) {
  var ed = e.ed;
  document.getElementById('manScr').classList.add('vis');
  document.getElementById('manEN').textContent = ed.name;
  updManSI();
  document.getElementById('manRT').textContent = e.t ? fmtTgt(e.r) : 'Target: ' + e.r;
  document.getElementById('manRN').textContent = '0';
  document.getElementById('manTap').style.display = '';
  rcState = { phase: 'up', reps: 0, cd: 0 };
  Snd.init();

  // Bind tap event
  var tap = document.getElementById('manTap');
  tap.onpointerdown = function (ev) { ev.preventDefault(); manTap(); };

  // Show/hide camera warning
  document.getElementById('camWarnBox').style.display = (showWarn && ed.ai) ? 'flex' : 'none';
}

function updManSI() { if (!ws) return; var e = ws.ex[ws.ei]; document.getElementById('manSI').textContent = 'Set ' + (ws.si + 1) + ' of ' + e.s; }

/** Handle tap — increment rep */
function manTap() {
  if (!ws) return;
  var e = ws.ex[ws.ei];
  rcState.reps++;

  var db = DB.get('set');
  if (db.sound) Snd.rep();
  if (navigator.vibrate) try { navigator.vibrate(15); } catch (e2) { /* no haptic */ }

  var el = document.getElementById('manRN');
  el.textContent = e.t ? fmtTm(rcState.reps) : rcState.reps;
  el.classList.add('bmp');
  setTimeout(function () { el.classList.remove('bmp'); }, 80);

  if (rcState.reps >= e.r) { onSetDone(e); }
}

/** Undo last rep */
function manUndo() {
  if (rcState.reps > 0) {
    rcState.reps--;
    var e = ws.ex[ws.ei];
    document.getElementById('manRN').textContent = e.t ? fmtTm(rcState.reps) : rcState.reps;
  }
}

function exitMan() {
  document.getElementById('manScr').classList.remove('vis');
  document.getElementById('manTap').style.display = '';
  document.getElementById('camWarnBox').style.display = 'none';
  endEarly();
}


/* ==============================================
   TIME-BASED EXERCISE (PLANK, WALL SIT)
   ============================================== */

function startTimeEx(e) {
  var ed = e.ed;
  document.getElementById('manScr').classList.add('vis');
  document.getElementById('manEN').textContent = ed.name;
  updManSI();
  document.getElementById('manRT').textContent = fmtTgt(e.r);
  document.getElementById('manRN').textContent = '0';
  document.getElementById('manTap').style.display = 'none';
  document.getElementById('camWarnBox').style.display = 'none';
  rcState = { phase: 'up', reps: 0, cd: 0 };
  Snd.init();

  var elapsed = 0;
  plankInt = setInterval(function () {
    elapsed++;
    rcState.reps = elapsed;
    document.getElementById('manRN').textContent = fmtTm(elapsed);
    if ((elapsed / e.r) * 100 >= 100) {
      clearInterval(plankInt); plankInt = null; onSetDone(e);
    } else if (elapsed === Math.floor(e.r / 2)) {
      var db = DB.get('set'); if (db.sound) Snd.half();
    }
  }, 1000);
}

/** Clear plank timer */
function clearPlank() { if (plankInt) { clearInterval(plankInt); plankInt = null; } }


/* ==============================================
   SET COMPLETE
   ============================================== */

/** Called when a set's target is reached */
function onSetDone(ex) {
  var db = DB.get('set');
  if (db.sound) Snd.set();

  // Record reps for this set
  ex.sr.push(rcState.reps);
  ws.si++;

  // Update overlay
  document.getElementById('setCR').textContent = rcState.reps + (ex.t ? ' seconds' : ' reps completed');
  var isLastSet = ws.si >= ex.s;
  var isLastEx = ws.ei >= ws.ex.length - 1;
  document.getElementById('setCNB').textContent = isLastSet && isLastEx ? 'Finish Workout' : isLastSet ? 'Next Exercise' : 'Next Set';

  document.getElementById('setCO').classList.add('vis');
  confetti();

  if (camOn) camPause = true;
  clearPlank();
}

/** Advance to next set or exercise */
function nextSet() {
  document.getElementById('setCO').classList.remove('vis');
  if (!ws) return;
  var e = ws.ex[ws.ei];

  if (ws.si >= e.s) {
    // Move to next exercise
    ws.ei++;
    ws.si = 0;
    if (ws.ei >= ws.ex.length) { finishWK(); return; }
    var ne = ws.ex[ws.ei];
    if (ne.rst > 0) showRest(ne.rst, ne.ed.name);
    else startCurEx();
  } else {
    // Rest between sets of same exercise
    if (e.rst > 0) showRest(e.rst, e.ed.name);
    else startCurEx();
  }
}


/* ==============================================
   REST TIMER
   ============================================== */

/**
 * Show rest timer between sets
 * @param {number} dur - Rest duration in seconds
 * @param {string} nextName - Name of next exercise
 */
function showRest(dur, nextName) {
  document.getElementById('restScr').classList.add('vis');
  document.getElementById('restNn').textContent = nextName;
  var rem = dur;
  var circ = document.getElementById('restCirc');
  var total = 553; // 2 * PI * 88
  circ.style.strokeDashoffset = '0';
  document.getElementById('restTm').textContent = rem;

  var db = DB.get('set');
  if (restInt) clearInterval(restInt);

  restInt = setInterval(function () {
    rem--;
    document.getElementById('restTm').textContent = rem;
    circ.style.strokeDashoffset = ((1 - rem / dur) * total).toString();
    if (rem <= 3 && rem > 0 && db.sound) Snd.cd();
    if (rem <= 0) {
      clearInterval(restInt); restInt = null;
      if (db.sound) Snd.go();
      document.getElementById('restScr').classList.remove('vis');
      startCurEx();
    }
  }, 1000);
}

/** Skip rest and start next exercise immediately */
function skipRest() {
  if (restInt) { clearInterval(restInt); restInt = null; }
  document.getElementById('restScr').classList.remove('vis');
  startCurEx();
}


/* ==============================================
   SKIP EXERCISE / END WORKOUT EARLY
   ============================================== */

/** Skip to next exercise */
function skipEx() {
  if (camOn) camPause = false;
  clearPlank();

  if (ws) {
    var e = ws.ex[ws.ei];
    if (rcState.reps > 0) e.sr.push(rcState.reps);
    ws.si = 0;
    ws.ei++;
    if (ws.ei >= ws.ex.length) {
      stopCam(); closeAllOverlays(); finishWK(); return;
    }
  }

  stopCam(); closeAllOverlays();
  if (ws) {
    var ne = ws.ex[ws.ei];
    if (ne && ne.rst > 0) showRest(ne.rst, ne.ed.name);
    else startCurEx();
  }
}

/** End workout early and save partial progress */
function endEarly() {
  clearPlank();
  if (ws) {
    var e = ws.ex[ws.ei];
    if (e && rcState.reps > 0) e.sr.push(rcState.reps);
  }
  stopCam();
  closeAllOverlays();
  if (ws) finishWK();
  else nav('s-home');
}

/** Close all overlay screens */
function closeAllOverlays() {
  ['camScr', 'manScr', 'restScr', 'setCO'].forEach(function (id) {
    document.getElementById(id).classList.remove('vis');
  });
  document.getElementById('manTap').style.display = '';
  document.getElementById('camWarnBox').style.display = 'none';
}


/* ==============================================
   WORKOUT FINISH / SUMMARY
   ============================================== */

/** Complete the workout and show summary */
function finishWK() {
  if (!ws) return;
  ws.done = true;

  var dur = Math.round((Date.now() - ws.st) / 1000);
  var totalReps = 0;
  ws.ex.forEach(function (e) { e.sr.forEach(function (r) { totalReps += r; }); });
  var calEst = Math.round(totalReps * 0.4 + dur * 0.15);

  // Build workout record
  var record = {
    id: uid(), name: ws.pn, date: new Date().toISOString(), dur: dur, tr: totalReps, cal: calEst,
    ex: ws.ex.filter(function (e) { return e.sr.length > 0; }).map(function (e) {
      return { id: e.id, name: e.ed.name, sets: e.sr.length, reps: e.sr.reduce(function (a, b) { return a + b; }, 0) };
    })
  };

  // Save to localStorage
  DB.addW(record);

  // Play completion sound
  var db = DB.get('set');
  if (db.sound) Snd.done();

  // Build summary HTML
  var exRows = ws.ex.map(function (e) {
    var totalR = e.sr.reduce(function (a, b) { return a + b; }, 0);
    return '<div class="ser"><div class="sei" style="background:' + e.ed.ib + ';color:' + e.ed.ic + '"><i class="fas ' + e.ed.icon + '"></i></div>' +
      '<div class="sef"><div class="en2">' + e.ed.name + '</div><div class="es">' + e.sr.length + ' sets · ' + (e.t ? fmtTm(totalR) : totalR + ' reps') + '</div></div>' +
      '<div class="er">' + (e.t ? fmtTm(totalR) : totalR) + '</div></div>';
  }).join('');

  document.getElementById('sumC').innerHTML =
    '<div class="sumh"><i class="fas fa-trophy"></i><div class="sht">Workout Complete</div><div class="shs">' + ws.pn + '</div></div>' +
    '<div class="ssg"><div class="ssi"><div class="sn" style="color:var(--accent)">' + fmtDur(dur) + '</div><div class="sl">Duration</div></div>' +
    '<div class="ssi"><div class="sn" style="color:var(--orange)">' + totalReps + '</div><div class="sl">Total Reps</div></div>' +
    '<div class="ssi"><div class="sn" style="color:var(--cyan)">' + calEst + '</div><div class="sl">Est. Calories</div></div></div>' +
    '<div class="sex"><div class="dt" style="margin-bottom:8px">Exercise Breakdown</div>' + exRows + '</div>' +
    '<div style="margin:24px 0"><button class="btn btn-p" style="width:100%;padding:16px;font-size:15px" onclick="closeSum()"><i class="fas fa-check"></i> Done</button></div>';

  document.getElementById('sumScr').classList.add('vis');
  ws = null;
}

function closeSum() {
  document.getElementById('sumScr').classList.remove('vis');
  nav('s-home');
}


/* ==============================================
   HISTORY SCREEN
   ============================================== */

function renderHist() {
  var st = DB.get('st');
  var w = DB.get('w') || [];

  document.getElementById('hStats').innerHTML =
    '<div class="hi"><div class="hn" style="color:var(--accent)">' + st.tw + '</div><div class="hl">Workouts</div></div>' +
    '<div class="hi"><div class="hn" style="color:var(--orange)">' + st.tr + '</div><div class="hl">Total Reps</div></div>' +
    '<div class="hi"><div class="hn" style="color:var(--cyan)">' + fmtDur(st.td) + '</div><div class="hl">Total Time</div></div>';

  var list = document.getElementById('hList');
  if (!w.length) {
    list.innerHTML = '<div class="empty"><i class="fas fa-clock-rotate-left"></i><p>No workouts yet.<br>Start your first workout to see history here.</p></div>';
    return;
  }

  list.innerHTML = w.slice(0, 20).map(function (wk) {
    return '<div class="hwi"><div class="ht"><div class="hwn">' + wk.name + '</div><div class="hwd">' + fmtDate(wk.date) + '</div></div>' +
      '<div class="hws"><div><span>' + fmtDur(wk.dur) + '</span> duration</div><div><span>' + wk.tr + '</span> reps</div>' +
      (wk.cal ? '<div><span>' + wk.cal + '</span> cal</div>' : '') + '</div></div>';
  }).join('');
}


/* ==============================================
   PROFILE SCREEN
   ============================================== */

function renderProf() {
  var st = DB.get('st');
  var set = DB.get('set');
  var jd = new Date(st.jd);
  document.getElementById('prJn').textContent = 'Joined ' + jd.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  document.getElementById('prStats').innerHTML = [
    { v: st.tw, l: 'Workouts', c: 'var(--accent)' },
    { v: st.tr, l: 'Total Reps', c: 'var(--orange)' },
    { v: fmtDur(st.td), l: 'Total Time', c: 'var(--cyan)' },
    { v: st.cs, l: 'Day Streak', c: 'var(--yellow)' }
  ].map(function (s) {
    return '<div class="psi"><div class="pv" style="color:' + s.c + '">' + s.v + '</div><div class="pl">' + s.l + '</div></div>';
  }).join('');

  document.getElementById('prSet').innerHTML =
    '<div class="dt" style="margin-bottom:12px">Settings</div>' +
    '<div class="srow"><div class="srl"><div class="sli"><i class="fas fa-volume-high"></i></div><div><div class="snm">Sound Effects</div><div class="sd">Rep and set completion sounds</div></div></div>' +
    '<div class="tog' + (set.sound ? ' on' : '') + '" onclick="togSound(this)"><div class="tk"></div></div></div>' +
    '<div class="srow"><div class="srl"><div class="sli"><i class="fas fa-trash-can" style="color:var(--red)"></i></div><div><div class="snm" style="color:var(--red)">Clear All Data</div><div class="sd">Remove all workouts and stats</div></div></div>' +
    '<button class="btn btn-sm btn-d" onclick="clearData()">Clear</button></div>' +
    '<div class="srow"><div class="srl"><div class="sli"><i class="fas fa-info-circle"></i></div><div><div class="snm">About JERAI</div><div class="sd">Version 1.0 — AI Bodyweight Fitness</div></div></div></div>';
}

/** Toggle sound effects on/off */
function togSound(el) {
  var s = DB.get('set');
  s.sound = !s.sound;
  DB.set('set', s);
  el.classList.toggle('on');
  toast(s.sound ? 'Sound enabled' : 'Sound disabled', 'inf');
}

/** Clear all stored data */
function clearData() {
  DB._d = DB.def();
  DB.save();
  renderProf();
  toast('All data cleared', 'inf');
}


/* ==============================================
   INITIALIZATION
   ============================================== */

document.addEventListener('DOMContentLoaded', function () {
  // Load saved data
  DB.load();

  // Pre-detect camera status
  detectCamStatus();

  // Hide splash screen after animation
  setTimeout(function () {
    var sp = document.getElementById('splash');
    sp.classList.add('hide');
    setTimeout(function () { sp.style.display = 'none'; renderHome(); }, 500);
  }, 1800);

  // Pause camera when tab becomes hidden
  document.addEventListener('visibilitychange', function () {
    if (document.hidden && camOn) {
      camPause = true;
      document.getElementById('camPB').innerHTML = '<i class="fas fa-play"></i>';
      document.getElementById('camPB').classList.add('act');
      document.getElementById('camDT').textContent = 'Paused';
    }
  });
});