/**
 * JERAI Fitness — Exercise Database
 * 
 * Each exercise contains:
 * - id: Unique identifier
 * - name: Display name
 * - icon: FontAwesome icon class
 * - muscle: Target muscle groups
 * - cat: Category (upper, lower, core, cardio)
 * - diff: Difficulty level
 * - cpr: Calories per rep (estimated)
 * - ai: Whether AI counting is supported
 * - tb: Time-based exercise (plank, wall sit)
 * - gr, ib, ic: Gradient/background/icon color
 * - ins: Step-by-step instructions
 * - tips: Form tips
 * - cnt: AI counting config (method, joints, thresholds)
 * - form: Optional form check function
 */

var EX = {
  'pushups': {
    id: 'pushups', name: 'Push-Ups', icon: 'fa-hand-fist',
    muscle: 'Chest, Triceps, Shoulders', cat: 'upper', diff: 'Beginner',
    cpr: .5, ai: true,
    gr: 'linear-gradient(135deg,#1a0f05,#2a1508)',
    ib: 'rgba(255,109,58,.12)', ic: '#ff6d3a',
    ins: [
      'Place hands shoulder-width apart, arms straight.',
      'Keep body straight from head to heels.',
      'Lower chest toward floor by bending elbows.',
      'Push back up to starting position.'
    ],
    tips: ['Engage core throughout', 'Don\'t flare elbows past 45 degrees', 'Breathe in going down, out pushing up'],
    cnt: { m: 'angle', j: [[11,13,15],[12,14,16]], dTh: 105, uTh: 155, sp: 'up', mn: false },
    form: function(l) {
      var a = ang(l[11], l[23], { x: l[27].x, y: Math.min(l[27].y, l[28].y) });
      return a < 150 ? { g: false, m: 'Keep body straight' } : { g: true };
    }
  },
  'wide-pushups': {
    id: 'wide-pushups', name: 'Wide Push-Ups', icon: 'fa-hand-fist',
    muscle: 'Chest, Shoulders', cat: 'upper', diff: 'Beginner', cpr: .5, ai: true,
    gr: 'linear-gradient(135deg,#1a0f05,#2a1508)', ib: 'rgba(255,109,58,.12)', ic: '#ff6d3a',
    ins: ['Place hands wider than shoulder-width.', 'Keep body straight.', 'Lower chest, elbows flaring out.', 'Push back up.'],
    tips: ['Focus on chest engagement', 'Control the descent'],
    cnt: { m: 'angle', j: [[11,13,15],[12,14,16]], dTh: 110, uTh: 155, sp: 'up' }
  },
  'diamond-pushups': {
    id: 'diamond-pushups', name: 'Diamond Push-Ups', icon: 'fa-gem',
    muscle: 'Triceps, Inner Chest', cat: 'upper', diff: 'Intermediate', cpr: .6, ai: true,
    gr: 'linear-gradient(135deg,#1a0f05,#2a1508)', ib: 'rgba(255,109,58,.12)', ic: '#ff6d3a',
    ins: ['Hands close together under chest.', 'Body straight, core engaged.', 'Lower chest to hands, elbows tucked.', 'Push back up fully.'],
    tips: ['Elbows close to body', 'Start on knees if needed'],
    cnt: { m: 'angle', j: [[11,13,15],[12,14,16]], dTh: 100, uTh: 150, sp: 'up' }
  },
  'pike-pushups': {
    id: 'pike-pushups', name: 'Pike Push-Ups', icon: 'fa-mountain',
    muscle: 'Shoulders, Triceps', cat: 'upper', diff: 'Intermediate', cpr: .55, ai: false,
    gr: 'linear-gradient(135deg,#1a0f05,#2a1508)', ib: 'rgba(255,109,58,.12)', ic: '#ff6d3a',
    ins: ['Start in downward dog position.', 'Hips high, hands and feet on floor.', 'Bend elbows, lower head toward floor.', 'Push back up.'],
    tips: ['Hips stay high throughout', 'Targets shoulders heavily']
  },
  'tricep-dips': {
    id: 'tricep-dips', name: 'Tricep Dips', icon: 'fa-chair',
    muscle: 'Triceps, Shoulders', cat: 'upper', diff: 'Beginner', cpr: .4, ai: false,
    gr: 'linear-gradient(135deg,#1a0f05,#2a1508)', ib: 'rgba(255,109,58,.12)', ic: '#ff6d3a',
    ins: ['Sit on edge of chair, hands next to hips.', 'Slide hips off, legs extended.', 'Lower by bending elbows to 90 degrees.', 'Push back up.'],
    tips: ['Keep back close to surface', 'Bend knees for easier version']
  },
  'decline-pushups': {
    id: 'decline-pushups', name: 'Decline Push-Ups', icon: 'fa-arrow-trend-up',
    muscle: 'Upper Chest, Shoulders', cat: 'upper', diff: 'Intermediate', cpr: .6, ai: false,
    gr: 'linear-gradient(135deg,#1a0f05,#2a1508)', ib: 'rgba(255,109,58,.12)', ic: '#ff6d3a',
    ins: ['Place feet elevated on surface.', 'Hands shoulder-width on floor.', 'Lower chest toward floor.', 'Push back up.'],
    tips: ['Elevate higher for more difficulty']
  },
  'squats': {
    id: 'squats', name: 'Squats', icon: 'fa-person',
    muscle: 'Quads, Glutes, Hamstrings', cat: 'lower', diff: 'Beginner', cpr: .6, ai: true,
    gr: 'linear-gradient(135deg,#051a1a,#082a2a)', ib: 'rgba(0,188,212,.12)', ic: '#00bcd4',
    ins: ['Feet shoulder-width, toes slightly out.', 'Chest up, back straight.', 'Push hips back, bend knees.', 'Lower until thighs parallel, drive up.'],
    tips: ['Weight in heels', 'Knees track over toes'],
    cnt: { m: 'angle', j: [[23,25,27],[24,26,28]], dTh: 100, uTh: 158, sp: 'up', mn: false },
    form: function(l) {
      var a = ang(l[23], l[25], l[27]);
      return a < 80 ? { g: false, m: 'Don\'t go too deep' } : { g: true };
    }
  },
  'jump-squats': {
    id: 'jump-squats', name: 'Jump Squats', icon: 'fa-person-running',
    muscle: 'Quads, Glutes, Calves', cat: 'lower', diff: 'Intermediate', cpr: .9, ai: true,
    gr: 'linear-gradient(135deg,#051a1a,#082a2a)', ib: 'rgba(0,188,212,.12)', ic: '#00bcd4',
    ins: ['Stand feet shoulder-width.', 'Lower into squat.', 'Explosively jump up.', 'Land softly, lower into next squat.'],
    tips: ['Land softly on balls of feet', 'Swing arms for power'],
    cnt: { m: 'angle', j: [[23,25,27],[24,26,28]], dTh: 100, uTh: 160, sp: 'up' }
  },
  'lunges': {
    id: 'lunges', name: 'Lunges', icon: 'fa-shoe-prints',
    muscle: 'Quads, Glutes, Hamstrings', cat: 'lower', diff: 'Beginner', cpr: .5, ai: true,
    gr: 'linear-gradient(135deg,#051a1a,#082a2a)', ib: 'rgba(0,188,212,.12)', ic: '#00bcd4',
    ins: ['Stand tall, feet hip-width.', 'Step forward, lowering hips.', 'Both knees bend to 90 degrees.', 'Push back, alternate legs.'],
    tips: ['Keep torso upright', 'Front knee over ankle'],
    cnt: { m: 'angle', j: [[23,25,27],[24,26,28]], dTh: 95, uTh: 158, sp: 'up', mn: true }
  },
  'reverse-lunges': {
    id: 'reverse-lunges', name: 'Reverse Lunges', icon: 'fa-shoe-prints',
    muscle: 'Quads, Glutes', cat: 'lower', diff: 'Beginner', cpr: .45, ai: true,
    gr: 'linear-gradient(135deg,#051a1a,#082a2a)', ib: 'rgba(0,188,212,.12)', ic: '#00bcd4',
    ins: ['Stand tall.', 'Step backward with one leg.', 'Lower hips until both knees 90 degrees.', 'Push back to start, alternate.'],
    tips: ['Easier on knees', 'Keep chest up'],
    cnt: { m: 'angle', j: [[23,25,27],[24,26,28]], dTh: 95, uTh: 158, sp: 'up', mn: true }
  },
  'calf-raises': {
    id: 'calf-raises', name: 'Calf Raises', icon: 'fa-arrow-up',
    muscle: 'Calves', cat: 'lower', diff: 'Beginner', cpr: .2, ai: false,
    gr: 'linear-gradient(135deg,#051a1a,#082a2a)', ib: 'rgba(0,188,212,.12)', ic: '#00bcd4',
    ins: ['Stand tall, feet hip-width.', 'Press through balls of feet, raise heels.', 'Squeeze calves at top.', 'Lower back down.'],
    tips: ['Hold wall for balance', 'Full range of motion']
  },
  'glute-bridges': {
    id: 'glute-bridges', name: 'Glute Bridges', icon: 'fa-bridge',
    muscle: 'Glutes, Hamstrings', cat: 'lower', diff: 'Beginner', cpr: .3, ai: false,
    gr: 'linear-gradient(135deg,#051a1a,#082a2a)', ib: 'rgba(0,188,212,.12)', ic: '#00bcd4',
    ins: ['Lie on back, knees bent, feet flat.', 'Drive through heels, lift hips.', 'Squeeze glutes at top, lower slowly.'],
    tips: ['Don\'t overextend back', 'Hold top 2 seconds']
  },
  'wall-sit': {
    id: 'wall-sit', name: 'Wall Sit', icon: 'fa-person',
    muscle: 'Quads, Glutes', cat: 'lower', diff: 'Beginner', cpr: 0, ai: false, tb: true,
    gr: 'linear-gradient(135deg,#051a1a,#082a2a)', ib: 'rgba(0,188,212,.12)', ic: '#00bcd4',
    ins: ['Back against wall.', 'Slide down, thighs parallel.', 'Knees at 90 degrees.', 'Hold for target time.'],
    tips: ['Thighs parallel to floor', 'Breathe steadily']
  },
  'situps': {
    id: 'situps', name: 'Sit-Ups', icon: 'fa-arrow-up',
    muscle: 'Abs, Hip Flexors', cat: 'core', diff: 'Beginner', cpr: .3, ai: true,
    gr: 'linear-gradient(135deg,#051a0f,#082a18)', ib: 'rgba(0,230,118,.12)', ic: '#00e676',
    ins: ['Lie back, knees bent, feet flat.', 'Hands behind ears.', 'Engage core, lift upper body.', 'Slowly lower back down.'],
    tips: ['Don\'t pull on neck', 'Use abs not momentum'],
    cnt: { m: 'angle', j: [[11,23,25],[12,24,26]], dTh: 65, uTh: 115, sp: 'down' }
  },
  'crunches': {
    id: 'crunches', name: 'Crunches', icon: 'fa-arrow-up',
    muscle: 'Upper Abs', cat: 'core', diff: 'Beginner', cpr: .2, ai: true,
    gr: 'linear-gradient(135deg,#051a0f,#082a18)', ib: 'rgba(0,230,118,.12)', ic: '#00e676',
    ins: ['Lie back, knees bent, feet flat.', 'Hands lightly behind head.', 'Lift upper back and shoulders only.', 'Squeeze abs, lower slowly.'],
    tips: ['Small range is fine', 'Lower back stays on floor'],
    cnt: { m: 'angle', j: [[11,23,25],[12,24,26]], dTh: 75, uTh: 120, sp: 'down' }
  },
  'bicycle-crunches': {
    id: 'bicycle-crunches', name: 'Bicycle Crunches', icon: 'fa-bicycle',
    muscle: 'Abs, Obliques', cat: 'core', diff: 'Intermediate', cpr: .35, ai: false,
    gr: 'linear-gradient(135deg,#051a0f,#082a18)', ib: 'rgba(0,230,118,.12)', ic: '#00e676',
    ins: ['Lie back, hands behind head, legs lifted.', 'Bring right knee to left elbow.', 'Extend right leg.', 'Alternate sides pedaling.'],
    tips: ['Rotate from core not neck', 'Keep lower back pressed down']
  },
  'leg-raises': {
    id: 'leg-raises', name: 'Leg Raises', icon: 'fa-arrow-up',
    muscle: 'Lower Abs', cat: 'core', diff: 'Intermediate', cpr: .3, ai: false,
    gr: 'linear-gradient(135deg,#051a0f,#082a18)', ib: 'rgba(0,230,118,.12)', ic: '#00e676',
    ins: ['Lie on back, legs straight.', 'Hands under hips.', 'Lift legs to 90 degrees.', 'Lower slowly without touching floor.'],
    tips: ['Press lower back into floor', 'Control the descent']
  },
  'plank': {
    id: 'plank', name: 'Plank', icon: 'fa-minus',
    muscle: 'Core, Shoulders', cat: 'core', diff: 'Beginner', cpr: 0, ai: true, tb: true,
    gr: 'linear-gradient(135deg,#051a0f,#082a18)', ib: 'rgba(0,230,118,.12)', ic: '#00e676',
    ins: ['Forearm plank, elbows under shoulders.', 'Body straight head to heels.', 'Engage core.', 'Hold position.'],
    tips: ['Don\'t let hips sag', 'Build up hold time'],
    cnt: { m: 'time' }
  },
  'side-plank': {
    id: 'side-plank', name: 'Side Plank', icon: 'fa-minus',
    muscle: 'Obliques, Core', cat: 'core', diff: 'Intermediate', cpr: 0, ai: false, tb: true,
    gr: 'linear-gradient(135deg,#051a0f,#082a18)', ib: 'rgba(0,230,118,.12)', ic: '#00e676',
    ins: ['Lie on side, prop on forearm.', 'Feet stacked.', 'Lift hips, body straight line.', 'Hold, then switch sides.'],
    tips: ['Don\'t let hips drop', 'Stack shoulders over elbow']
  },
  'flutter-kicks': {
    id: 'flutter-kicks', name: 'Flutter Kicks', icon: 'fa-water',
    muscle: 'Lower Abs', cat: 'core', diff: 'Beginner', cpr: .2, ai: false,
    gr: 'linear-gradient(135deg,#051a0f,#082a18)', ib: 'rgba(0,230,118,.12)', ic: '#00e676',
    ins: ['Lie on back, hands under hips.', 'Lift legs slightly off floor.', 'Alternate kicking legs up and down.'],
    tips: ['Small controlled movements', 'Keep lower back pressed down']
  },
  'mountain-climbers': {
    id: 'mountain-climbers', name: 'Mountain Climbers', icon: 'fa-mountain',
    muscle: 'Core, Cardio', cat: 'cardio', diff: 'Intermediate', cpr: .4, ai: true,
    gr: 'linear-gradient(135deg,#1a0505,#2a0808)', ib: 'rgba(255,82,82,.12)', ic: '#ff5252',
    ins: ['High plank, arms straight.', 'Drive one knee toward chest.', 'Return leg, drive other knee.', 'Continue alternating.'],
    tips: ['Keep hips level', 'Start slow then speed up'],
    cnt: { m: 'dist', rj: [[25,23],[26,24]], nj: [[11,23],[12,24]], cTh: .2, fTh: .45, sp: 'close', cps: true }
  },
  'jumping-jacks': {
    id: 'jumping-jacks', name: 'Jumping Jacks', icon: 'fa-person-rays',
    muscle: 'Full Body, Cardio', cat: 'cardio', diff: 'Beginner', cpr: .3, ai: true,
    gr: 'linear-gradient(135deg,#1a0505,#2a0808)', ib: 'rgba(255,82,82,.12)', ic: '#ff5252',
    ins: ['Stand feet together, arms at sides.', 'Jump spreading legs wide.', 'Raise arms overhead.', 'Jump back to start.'],
    tips: ['Land softly', 'Keep steady rhythm'],
    cnt: { m: 'dist', rj: [[15,16]], nj: [[11,12]], cTh: 1.8, fTh: 3.5, sp: 'close' }
  },
  'high-knees': {
    id: 'high-knees', name: 'High Knees', icon: 'fa-person-running',
    muscle: 'Core, Quads, Cardio', cat: 'cardio', diff: 'Beginner', cpr: .3, ai: true,
    gr: 'linear-gradient(135deg,#1a0505,#2a0808)', ib: 'rgba(255,82,82,.12)', ic: '#ff5252',
    ins: ['Stand feet hip-width.', 'Drive one knee to chest height.', 'Quickly lower, drive other knee.', 'Pump arms.'],
    tips: ['Knees to waist height', 'Maintain upright posture'],
    cnt: { m: 'ht', kj: [25,26], hj: [23,24], hTh: .7, cps: true }
  },
  'burpees': {
    id: 'burpees', name: 'Burpees', icon: 'fa-bolt',
    muscle: 'Full Body, Cardio', cat: 'cardio', diff: 'Advanced', cpr: 1.2, ai: true,
    gr: 'linear-gradient(135deg,#1a0505,#2a0808)', ib: 'rgba(255,82,82,.12)', ic: '#ff5252',
    ins: ['Stand shoulder-width.', 'Drop to squat, hands on floor.', 'Jump feet back to plank.', 'Jump feet to hands, jump up.'],
    tips: ['Form over speed', 'Step instead of jump to modify'],
    cnt: { m: 'angle', j: [[23,25,27],[24,26,28]], dTh: 95, uTh: 158, sp: 'up' }
  }
};